import random
import sys
from collections import deque
from .maze import MazeOptions, Maze, MazeError
from typing import Self, Any


PATTERN_42 = [
    [1, 0, 1, 0, 1, 1, 1],
    [1, 0, 1, 0, 0, 0, 1],
    [1, 1, 1, 0, 1, 1, 1],
    [0, 0, 1, 0, 1, 0, 0],
    [0, 0, 1, 0, 1, 1, 1],
]
"""Bitmap of the '42' logo. 1 = cell stays fully closed (wall=15)."""


class MazeGenerator():
    """Build, solve and serialize a maze from a MazeOptions."""

    def __init__(self, options: MazeOptions) -> None:
        """Initialize the generator state from validated options."""
        self.width = options.width
        self.height = options.height
        self.entry = options.entry
        self.exit = options.exit
        self.perfect = options.perfect
        random.seed(options.seed)
        self.grid = [[15 for i in range(self.width)]
                     for i in range(self.height)]
        pattern_h = len(PATTERN_42)
        pattern_w = len(PATTERN_42[0])
        self.has_forty_two: bool = (
            self.width >= pattern_w + 2 and self.height >= pattern_h + 2
        )
        self.pattern_cells: set[tuple[int, int]] = set()
        self.output_file = options.output_file

        if self.has_forty_two:
            start_x = (self.width - pattern_w) // 2
            start_y = (self.height - pattern_h) // 2
            self.pattern_cells = {
                (start_x + px, start_y + py)
                for py in range(pattern_h)
                for px in range(pattern_w)
                if PATTERN_42[py][px] == 1
            }
        else:
            print(
                f"Warning: maze size ({self.width}x{self.height})"
                f"too small for '42' pattern, logo",
                file=sys.stderr
            )

    @classmethod
    def from_config_file(cls, config_file: str) -> Self:
        """Build a generator from a KEY=VALUE configuration file."""
        MANDATORY_KEYS = ['WIDTH', 'HEIGHT', 'ENTRY', 'EXIT', 'OUTPUT_FILE',
                          'PERFECT']
        OPTIONAL_KEYS = ['SEED']

        config = {}

        try:
            with open(config_file, 'r') as file:
                lines = file.readlines()
                for line in lines:
                    line = line.strip()

                    if not line or line.startswith('#'):
                        continue

                    if '=' in line:
                        invalid = False
                        value: Any
                        key, value = line.split('=', 1)

                        if key.lower() in config:
                            continue

                        if value.lower() == 'true':
                            value = True
                        elif value.lower() == 'false':
                            value = False
                        elif ',' in value:
                            try:
                                value = tuple(int(v) for v in value.split(','))
                            except ValueError:
                                pass
                            if len(value) != 2:
                                invalid = True
                        else:
                            try:
                                value = int(value)
                            except ValueError:
                                pass

                        if not invalid:
                            config[key.lower()] = value
        except OSError:
            raise MazeError("Invalid config file")

        missing = [key for key in MANDATORY_KEYS if key.lower() not in config]
        if missing:
            raise MazeError(f"Missing mandatory config keys: {missing}")

        known_keys = set(MANDATORY_KEYS + OPTIONAL_KEYS)

        for key in [key for key in config if key.upper() not in known_keys]:
            del config[key]

        options = MazeOptions(**config)

        return cls(options)

    def _get_unvisited_neighbors(
        self, x: int, y: int, visited: list[list[bool]]
    ) -> list[tuple[int, int]]:
        """Return the in-bounds, not-yet-visited neighbors of (x, y)."""
        neighbors = []
        directions = [(0, -1), (1, 0), (0, 1), (-1, 0)]
        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.width and 0 <= ny < self.height:
                if not visited[ny][nx]:
                    neighbors.append((nx, ny))
        return neighbors

    def _remove_wall(self, x1: int, y1: int, x2: int, y2: int) -> None:
        """Open the wall shared by two adjacent cells."""
        if y2 < y1:  # North
            self.grid[y1][x1] &= ~1
            self.grid[y2][x2] &= ~4
        elif x2 > x1:  # East
            self.grid[y1][x1] &= ~2
            self.grid[y2][x2] &= ~8
        elif y2 > y1:  # South
            self.grid[y1][x1] &= ~4
            self.grid[y2][x2] &= ~1
        elif x2 < x1:  # West
            self.grid[y1][x1] &= ~8
            self.grid[y2][x2] &= ~2

    def _add_wall(self, x1: int, y1: int, x2: int, y2: int) -> None:
        """Close the wall shared by two adjacent cells."""
        if y2 < y1:
            self.grid[y1][x1] |= 1
            self.grid[y2][x2] |= 4
        elif x2 > x1:
            self.grid[y1][x1] |= 2
            self.grid[y2][x2] |= 8
        elif y2 > y1:
            self.grid[y1][x1] |= 4
            self.grid[y2][x2] |= 1
        elif x2 < x1:
            self.grid[y1][x1] |= 8
            self.grid[y2][x2] |= 2

    def _would_create_3x3_open(
            self, x1: int, y1: int, x2: int, y2: int
    ) -> bool:
        """Check whether opening a wall would create a 3x3 open area."""
        self._remove_wall(x1, y1, x2, y2)
        xmin, xmax = min(x1, x2), max(x1, x2)
        ymin, ymax = min(y1, y2), max(y1, y2)
        result = False
        for X in range(max(0, xmax - 2), min(self.width - 3, xmin) + 1):
            for Y in range(max(0, ymax - 2), min(self.height - 3, ymin) + 1):
                if self._is_3x3_open(X, Y):
                    result = True
        self._add_wall(x1, y1, x2, y2)
        return result

    def _is_3x3_open(self, X: int, Y: int) -> bool:
        """Return True if the 3x3 block at (X, Y) is fully open."""
        for dx in range(2):
            for dy in range(3):
                if self.grid[Y + dy][X + dx] & 2:
                    return False
        for dx in range(3):
            for dy in range(2):
                if self.grid[Y + dy][X + dx] & 4:
                    return False
        return True

    def _imperfect(self) -> None:
        """Break roughly 10% of internal walls to create multiple paths."""
        candidates = []
        for y in range(self.height):
            for x in range(self.width):
                if (x, y) in self.pattern_cells:
                    continue
                if (x + 1 < self.width
                        and (x + 1, y) not in self.pattern_cells
                        and self.grid[y][x] & 2):
                    candidates.append((x, y, x + 1, y))
                if (y + 1 < self.height
                        and (x, y + 1) not in self.pattern_cells
                        and self.grid[y][x] & 4):
                    candidates.append((x, y, x, y + 1))
        random.shuffle(candidates)
        target = max(1, len(candidates) // 10)
        removed = 0
        for x1, y1, x2, y2 in candidates:
            if removed >= target:
                break
            if not self._would_create_3x3_open(x1, y1, x2, y2):
                self._remove_wall(x1, y1, x2, y2)
                removed += 1

    def generate(self) -> list[list[int]]:
        """Carve the maze with an iterative DFS (recursive backtracker)."""
        visited = [[False for i in range(self.width)]
                   for i in range(self.height)]
        for (x, y) in self.pattern_cells:
            visited[y][x] = True

        stack = []
        start_x, start_y = 0, 0
        visited[start_y][start_x] = True
        stack.append((start_x, start_y))

        while stack:
            x, y = stack[-1]
            neighbors = self._get_unvisited_neighbors(x, y, visited)
            if neighbors:
                nx, ny = random.choice(neighbors)
                self._remove_wall(x, y, nx, ny)
                visited[ny][nx] = True
                stack.append((nx, ny))
            else:
                stack.pop()

        if self.entry in self.pattern_cells:
            raise MazeError("the 42 pattern overlap with the entrance")
        if self.exit in self.pattern_cells:
            raise MazeError("the 42 pattern overlap with the exit")

        return self.grid

    def solve(self, entry: tuple[int, int], exit_pos: tuple[int,
              int]) -> tuple[list[tuple[int, int]], str]:
        """Return the shortest path and its N/E/S/W string via BFS."""
        visited = [[False for i in range(self.width)]
                   for i in range(self.height)]
        came_from = {}
        queue: deque[tuple[int, int]] = deque()

        start_x, start_y = entry
        visited[start_y][start_x] = True
        queue.append((start_x, start_y))

        directions = {
            (0, -1): ("N", 1),
            (1, 0): ("E", 2),
            (0, 1): ("S", 4),
            (-1, 0): ("W", 8),
        }

        while queue:
            x, y = queue.popleft()
            if (x, y) == exit_pos:
                break
            for (dx, dy), (direction, wall_bit) in directions.items():
                nx, ny = x + dx, y + dy
                if 0 <= nx < self.width and 0 <= ny < self.height:
                    if not visited[ny][nx] and self.grid[y][x] & wall_bit == 0:
                        visited[ny][nx] = True
                        came_from[(nx, ny)] = (x, y)
                        queue.append((nx, ny))

        path_coords = []
        current = exit_pos
        while current != entry:
            path_coords.append(current)
            current = came_from[current]
        path_coords.append(entry)
        path_coords.reverse()

        path_directions = ""
        for i in range(len(path_coords) - 1):
            x1, y1 = path_coords[i]
            x2, y2 = path_coords[i + 1]
            dx, dy = x2 - x1, y2 - y1
            for (ddx, ddy), (direction, _) in directions.items():
                if dx == ddx and dy == ddy:
                    path_directions += direction
                    break
        return path_coords, path_directions

    def build(self) -> Maze:
        """Run the full pipeline and return a Maze instance."""
        self.grid = [[15] * self.width for i in range(self.height)]
        self.generate()
        if not self.perfect:
            self._imperfect()
        path_coords, path_directions = self.solve(self.entry, self.exit)
        return Maze(
            grid=self.grid,
            entry=self.entry,
            exit=self.exit,
            path=path_coords,
            mask=list(self.pattern_cells),
            path_directions=path_directions,
        )

    @staticmethod
    def write_maze(maze: Maze, output_file: str) -> None:
        """Serialize a Maze to the subject's output format."""
        with open(output_file, "w") as f:
            for row in maze.grid:
                line = "".join(f"{cell:X}" for cell in row)
                f.write(line + "\n")
            f.write("\n")
            f.write(f"{maze.entry[0]},{maze.entry[1]}\n")
            f.write(f"{maze.exit[0]},{maze.exit[1]}\n")
            f.write(f"{maze.path_directions}\n")
